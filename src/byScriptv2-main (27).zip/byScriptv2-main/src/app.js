const appRoot = document.getElementById("app");

if (appRoot) {
  appRoot.setAttribute("data-ready", "true");
}
